package programa;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tablas.PruebaId;
import utils.HibernateUtils;

public class Prueba {
	
	private static Session session;
	
	public static void main(String[] arg){
		//abrimos la sesion con Hibernate
		session = HibernateUtils.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		
		//creamos la prueba
		createPrueba("Marco","Lopez", 25);
		
		tx.commit();
		session.close();
		
		System.exit(0);
		
	}
	
	public static void createPrueba(String nombre, String apellido, int edad){
		PruebaId p = new PruebaId(nombre, apellido, edad);
		session.save(p);
	}

}
